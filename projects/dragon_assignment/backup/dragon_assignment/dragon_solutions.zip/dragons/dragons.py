from characters import *
from places import *
from assault_plans import *
from layouts import *
from dragons_strategies import start_with_strategy
from utils import *

setattr(DragonKing, "instantiated", False)
