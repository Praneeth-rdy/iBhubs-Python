from .fighter import Fighter
from .dragons import *
from .terminators import *
