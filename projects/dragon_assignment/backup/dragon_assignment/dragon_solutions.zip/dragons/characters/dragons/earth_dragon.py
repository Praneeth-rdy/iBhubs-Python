class EarthDragon:
    # ADD/OVERRIDE CLASS ATTRIBUTES HERE
    pass
