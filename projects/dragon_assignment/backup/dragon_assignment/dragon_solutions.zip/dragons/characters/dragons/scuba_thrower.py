class ScubaThrower:
    # ADD/OVERRIDE CLASS ATTRIBUTES HERE
    pass
